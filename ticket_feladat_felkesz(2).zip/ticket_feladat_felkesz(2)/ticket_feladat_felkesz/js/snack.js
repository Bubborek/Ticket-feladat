const snackRows = document.querySelectorAll('#snack-table tbody tr');

snackRows.forEach(row => {
    const minusButton = row.querySelector('.minus');
    const plusButton = row.querySelector('.plus');
    const quantitySpan = row.querySelector('.quantity');

    let quantity = 0;

    minusButton.addEventListener('click', () => {
        if (quantity > 0) {
            quantity--;
            quantitySpan.innerText = quantity;
        }
    });

    plusButton.addEventListener('click', () => {
        quantity++;
        quantitySpan.innerText = quantity;
    });

    const addToCartButton = row.querySelector('.add-to-cart');
    addToCartButton.addEventListener('click', () => {
        alert(`${row.children[0].innerText} hozzáadva a kosárhoz! Mennyiség: ${quantity}`);
    });
});
