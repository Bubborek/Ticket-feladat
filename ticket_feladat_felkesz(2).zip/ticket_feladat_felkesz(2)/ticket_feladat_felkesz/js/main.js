let currentDate = new Date();
let defaultDate = new Date(currentDate.getTime() + 2 * 24 * 60 * 60 * 1000);
document.getElementById('date').valueAsDate = defaultDate;
document.getElementById('submit').addEventListener('click', (event) => {
    event.preventDefault();
    let name = document.getElementById('name').value;
    let date = document.getElementById('date').value;
    let dropdown = document.getElementById('dropdown').value;
    if (name === "") {
        alert('Add meg a neved!');
        return;
    }
    if (isNaN(new Date(date))) {
        alert('Nem megfelelő dátum formátum!');
        return;
    }
    if (new Date(date) < currentDate) {
        alert('Nem lehet a múltba utazni!');
        return;
    }
    const newPassenger = {
        name: name,
        date: date,
        depart: dropdown
    }
    localStorage.setItem('newPassenger', JSON.stringify(newPassenger));
    window.location.href="ticket.html"
});