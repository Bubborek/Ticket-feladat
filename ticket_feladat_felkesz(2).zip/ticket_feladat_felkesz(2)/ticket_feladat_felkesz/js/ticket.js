function generateRandomNumber(min,max){
    return Math.floor(Math.random() * (max-min+1) + min);
}

function generateRandomEightNumbers(){
    let numbers = '';
    for (let i = 0; i < 8; i++){
        numbers += generateRandomNumber(0,9);
    }
    return numbers;
}

function generateRandomLetter(){
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    return letters[generateRandomNumber(0, letters.length-1)];
}

document.querySelector('.snack').addEventListener('click', () => {
    window.location.href = 'snack.html';
});

let newPassenger = JSON.parse(localStorage.getItem('newPassenger'));
let date = `${newPassenger.date.split('-')[0]}.${newPassenger.date.split('-')[1]}.${newPassenger.date.split('-')[2]}.`;
let timeMinutes = generateRandomNumber(0,59);
let time = `${generateRandomNumber(0,23)}:${timeMinutes >= 10 ? timeMinutes : '0' + timeMinutes}`;
let barcode = generateRandomEightNumbers();
document.getElementById('car').innerText = generateRandomNumber(1,30);
document.getElementById('seat').innerHTML = `${generateRandomNumber(1,150)}${generateRandomLetter()}`;
document.getElementById('date').innerText = date;
document.getElementById('date_side').innerText = date;
document.getElementById('time').innerText = time;
document.getElementById('time_side').innerText = time;
document.getElementById('barcode_id').innerText = barcode;
document.getElementById('barcode_id_side').innerText = barcode;
document.getElementById('passenger').innerText = newPassenger.name;
document.getElementById('depart').innerText = newPassenger.depart;
document.getElementById('depart_side').innerText = newPassenger.depart;